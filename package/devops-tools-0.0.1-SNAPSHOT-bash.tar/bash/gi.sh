git add .
git commit -m "Initial"
gph main
